package inou.net.rpc;

import java.io.IOException;


public class BinStreamException extends IOException {

	public BinStreamException(String m) {
		super(m);
	}

}