package inou.net.rpc;


public interface IMessageHandler {

	public Object send(Object[] args) throws Exception;

}
