/* INOU-utils
 *	Copyright (C) 2006 SAKURAI, Masashi (m.sakurai@dream.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

package inou.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import org.apache.log4j.Logger;
import java.util.Iterator;


public class Statistics {

	private HashMap statMap = new HashMap();
	private Calendar beginTime = getTodayFirst();
	private final static long TIME_OF_ADAY = 24*3600*1000;
	private final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy/MM/dd");

	private Logger logger = null;

	public Statistics(Logger logger) {
		this.logger = logger;
	}

	public synchronized long count(String id) {
		rotate();
		Counter c = getCounter(id);
		c.increment();
		return c.get();
	}

	public synchronized long get(String id) {
		return getCounter(id).get();
	}

	public String getReport() {
		StringBuffer sb = new StringBuffer("---(Statistics report)--------\n");
		sb.append(DATE_FORMAT.format(beginTime.getTime())).append("\n");
		if (statMap.size() == 0) {
			sb.append("No statistics.\n");
		} else {
			Iterator it = statMap.keySet().iterator();
			while(it.hasNext()) {
				String id = (String)it.next();
				Counter counter = getCounter(id);
				sb.append(id).append(" : ");
				sb.append(Long.toString(counter.get()));
				sb.append("\n");
			}
		}
		sb.append("---------------------------");
		return sb.toString();
	}

	private static Calendar getTodayFirst() {
		GregorianCalendar cal = new GregorianCalendar();
		GregorianCalendar first = 
			new GregorianCalendar(cal.get(Calendar.YEAR),
								  cal.get(Calendar.MONTH),
								  cal.get(Calendar.DATE));
		return first;
	}

	private void rotate() {
		long diff = System.currentTimeMillis() - beginTime.getTime().getTime();
		if (diff > TIME_OF_ADAY) {
			flush();
		}
	}

	public synchronized void flush() {
		logger.info(getReport());
		statMap.clear();
		beginTime = getTodayFirst();
	}

	private Counter getCounter(String id) {
		Counter obj = (Counter)statMap.get(id);
		if (obj != null) return obj;
		obj = new Counter();
		statMap.put(id,obj);
		return obj;
	}

	//=======================================================

	public static void main(String [] args) {
		int num = 16;
		Logger logger = Logger.getLogger(Statistics.class);
		for(int i=0;i<8;i++) {
			long time = sample(logger,new Statistics(logger),num);
			logger.info("num="+num+" : time="+time);
			num *= 2;
		}
	}

	private static long sample(Logger logger,
							   Statistics target,int num) {
		long begin = System.currentTimeMillis();
		Thread [] threads = new Thread[num];
		Counter finishCount = new Counter();
		Object waitObj = new Boolean(true);
		for (int i=0;i<num;i++) {
			String id = Integer.toString(i);
			threads[i] = new Thread(Thread.currentThread().getThreadGroup(),new ThreadTester(target,id,num,finishCount,waitObj));
		}
		for (int i=0;i<num;i++) {
			threads[i].start();
		}
		synchronized(waitObj) {
			try {
				while(finishCount.get() != num) {
					waitObj.wait();
				}
			} catch (Exception e) {
			}
		}
		for (int i=0;i<num;i++) {
			int count = (int)(target.get(Integer.toString(i)));
			if ( count != num) {
				logger.warn("Wrong : ["+i+"] = "+count +"("+num+")");
			}
		}
		return System.currentTimeMillis()-begin;
	}

	static class ThreadTester implements Runnable {
		private String id;
		private int count;
		private Statistics target;
		private Object waitObj;
		private Counter finishCount;
		ThreadTester(Statistics target,String id,int count,
					 Counter finishCount,Object obj) {
			this.id = id;
			this.count = count;
			this.target = target;
			this.waitObj = obj;
			this.finishCount = finishCount;
		}
		
		public void run() {
			for(int i=0;i<count;i++) {
				randomWait();
				target.count(Integer.toString(i));
			}
			synchronized(waitObj) {
				finishCount.increment();
				waitObj.notifyAll();
			}
		}

		private void randomWait() {
			try {
				Thread.sleep((int)(Math.random()*10));
			} catch(InterruptedException e) {
			}
		}

	}

}

class Counter {
	private long count = 0;
	void increment() {
		count++;
	}
	void reset() {
		count=0;
	}
	long get() {
		return count;
	}
}

