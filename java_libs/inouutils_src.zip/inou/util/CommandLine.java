/* INOU-utils
 *	Copyright (C) 2006 SAKURAI, Masashi (m.sakurai@dream.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

package inou.util;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;


public class CommandLine {
	
	private final static String separator = ":";

	private HashMap table = new HashMap();
	private List argumentList = new LinkedList();

	public CommandLine(String[] args) {
		if (args == null || args.length == 0) {
			return;
		}
		for (int i=0;i<args.length;i++) {
			if (args[i].charAt(0)!='-') {
				argumentList.add(args[i]);
				continue;
			}
			int ps = args[i].indexOf(separator);
			if (ps == -1) {
				table.put(args[i].substring(1),Boolean.TRUE);//without content
			} else {
				setOption(args[i].substring(1,ps),//option name
						  args[i].substring(ps+1));//option content
			}
		}
	}

	private void setOption(String key,String content) {
		if (content.equalsIgnoreCase("true") || 
			content.equalsIgnoreCase("yes")) {
			table.put(key,Boolean.TRUE);
		} else if (content.equalsIgnoreCase("false") || 
				   content.equalsIgnoreCase("no")) {
			table.put(key,Boolean.FALSE);
		} else {
			table.put(key,content);
		}
	}

	public String[] getArguments() {
		String[] rets = new String[argumentList.size()];
		return (String[])argumentList.toArray(rets);
	}

	public String[] getOptionKeys() {
		String [] ret = new String[table.size()];
		Iterator keys = table.keySet().iterator();
		int i=0;
		while(keys.hasNext()) {
			String key = (String)keys.next();
			ret[i++]= key;
		}
		return ret;
	}

	protected Object getOptionObject(String key) {
		return table.get(key);
	}

	public String getDumpProperties() {
		StringBuffer sb = new StringBuffer();
		String[] keys = getOptionKeys();
		for (int i=0;i<keys.length;i++){
			String cont = getOptionObject(keys[i]).toString();
			sb.append(keys[i]+":"+cont+"\n");
		}
		String[] files = getArguments();
		for (int i=0;i<files.length;i++) {
			sb.append("ARGS:"+files[i]+"\n");
		}
		return sb.toString();
	}

	/**
	   @param optionName option name that you want to get
	   @return option boolean. if wrong format or no option input, return false.
	 */
	public boolean getOption(String optionName) {
		return getOption(optionName,false);
	}

	/**
	   @param optionName option name that you want to get
	   @param def defualt value
	   @return option boolean. if wrong format or no option input, return defualt value.
	 */
	public boolean getOption(String optionName,boolean def) {
		Object obj = getOptionObject(optionName);
		if (obj == null || !(obj instanceof Boolean)) return def;
		return ((Boolean)obj)==Boolean.TRUE ? true:false;
	}
	
	/**
	   @param optionName option name that you want to get
	   @return option boolean. if wrong format or no option input, return null.
	 */
	public String getOptionString(String optionName) {
		return getOptionString(optionName,null);
	}

	/**
	   @param optionName option name that you want to get
	   @param def defualt value
	   @return option boolean. if wrong format or no option input, return defualt value.
	 */
	public String getOptionString(String optionName,String def) {
		Object obj = getOptionObject(optionName);
		if (obj == null) return def;
		if (!(obj instanceof String)) return obj.toString();
		return (String)obj;
	}

	/**
	   @param optionName option name that you want to get
	   @return option boolean. if wrong format or no option input, return -1.
	 */
	public int getOptionInteger(String optionName) {
		return getOptionInteger(optionName,-1);
	}

	private boolean isNull(String a) {
		return a == null || a.length() == 0;
	}

	/**
	   @param optionName option name that you want to get
	   @param def defualt value
	   @return option boolean. if wrong format or no option input, return defualt value.
	 */
	public int getOptionInteger(String optionName,int def) {
		String ret = getOptionString(optionName);
		if (isNull(ret)) {
			return def;
		}
		return Integer.parseInt(ret);
	}

	/**
	   @param optionName option name that you want to get
	   @return option boolean. if wrong format or no option input, return -1.
	 */
	public double getOptionDouble(String optionName) {
		return getOptionDouble(optionName,-1);
	}

	/**
	   @param optionName option name that you want to get
	   @param def defualt value
	   @return option boolean. if wrong format or no option input, return defualt value.
	 */
	public double getOptionDouble(String optionName,double def) {
		String ret = getOptionString(optionName);
		if (isNull(ret)) return def;
		return Double.parseDouble(ret);
	}

	public String getArgument() {
		if (getArguments().length == 0) return null;
		return getArguments()[0];
	}

}
