/* INOU-utils
 *	Copyright (C) 2006 SAKURAI, Masashi (m.sakurai@dream.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

package inou.util;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;


/** File System utility class. */
public class FileSystemUtil {

	/** 
	 *@param  src source file name.
	 *@param  dist distnation file name.
	 */
	public static void copy(String src,String dist) throws IOException {
		String message = "Opening files";
		FileInputStream fin = new FileInputStream(src);
		try {
			FileOutputStream fout = new FileOutputStream(dist);
			try {
				BufferedInputStream in = new BufferedInputStream(fin);
				BufferedOutputStream out = new BufferedOutputStream(fout);
				message = "Copying files";
				File source = new File(src);
				long sz = source.length();
				for(long i = 0;i<sz;i++) {
					out.write(in.read());
				}
			} catch (IOException e) {
				IOException ex = new IOException(e.getClass().getName()+"	 "+
											  e.getMessage()+"	 in FS.copy.["+message+"]");
				ex.initCause(e);
				throw ex;
			} finally {
				if (fout != null) {
					try {
						fout.close();
					} catch (IOException e) {}
				}
			}
		} finally {
			if (fin != null) {
				try {
					fin.close();
				} catch(Exception ex) {}
			}
		}
	}

	/**
	 * read a file and store lines into a list container 
	 */
	public static List readFile(String filename) throws IOException {
		return readFile(filename,System.getProperty("file.encoding"));
	}

	/** 
	 * read a file and store lines into a list container 
	 */
	public static List readFile(String filename,String encoding) throws IOException {
		if (filename == null) {
			return null;
		}
		ArrayList source = new ArrayList();

		FileInputStream fin = new FileInputStream(filename);
		try {
			BufferedReader in =  new BufferedReader(new InputStreamReader(fin,encoding));
			while (in.ready()) {
				source.add(in.readLine());
			}
		} finally {
			try {
				if (fin != null) {
					fin.close();
				}
			} catch (IOException e) {}
		}
		return source;
	}

	/** [UTILITY]
	 * read a file and store a string object
	 */
	public static String file2String(String filename) {
		return file2String(filename,System.getProperty("file.encoding"));
	}

	/** [UTILITY]
	 * read a file and store a string object
	 */
	public static String file2String(String filename,String encoding) {
		try {
			BufferedReader in =  new BufferedReader(new InputStreamReader(new FileInputStream(filename),encoding));
			StringBuffer out = new StringBuffer();
			while (in.ready()) {
				out.append(in.readLine());
				if (in.ready()) {
					out.append("\n");
				}
			}
			return out.toString();
		} catch (IOException e) {
		}
		return null;
	}

	public static void string2File(String source,String filename,String encoding) throws IOException {
		FileOutputStream fout = new FileOutputStream(filename);
		try {
			OutputStreamWriter out = new OutputStreamWriter(new BufferedOutputStream(fout),encoding);
			out.write(source,0,source.length());
		} catch (IOException e) {
			IOException ex = new IOException(e.getClass().getName()+"	 "+
										   e.getMessage()+"	 in FS.copy.");
			ex.initCause(e);
			throw ex;
		} finally {
			if (fout != null) {
				try {
					fout.close();
				} catch (IOException e) {}
			}
		}
	}

	public static void string2File(String source,String filename) throws IOException {
		string2File(source,filename,System.getProperty("file.encoding"));
	}
}

